package com.easyvictory.mods;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class CrmKeyStore {
    private static final String ALIAS = "victory.crm.license.v2";
    private CrmKeyStore() {}
    private static SecretKey key(boolean create) throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (!store.containsAlias(ALIAS) && create) {
            KeyGenerator generator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setKeySize(256).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());
            generator.generateKey();
        }
        return (SecretKey)store.getKey(ALIAS, null);
    }
    static void write(Context context, String license) {
        // No plaintext fallback on old devices or Keystore failures.
        try {
            if (context == null || Build.VERSION.SDK_INT < 23) return;
            if (license == null || license.trim().isEmpty()) {
                context.getSharedPreferences("crm_auth", Context.MODE_PRIVATE).edit().remove("license").apply();
                return;
            }
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key(true));
            String value = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP)+"."+
                Base64.encodeToString(cipher.doFinal(license.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP);
            context.getSharedPreferences("crm_auth", Context.MODE_PRIVATE).edit().putString("license", value).apply();
        } catch (Exception failure) {
            if (context != null) {
                context.getSharedPreferences("crm_auth", Context.MODE_PRIVATE).edit().remove("license").apply();
            }
        }
    }
    static void clear(Context context) {
        write(context, "");
    }
    static String read(Context context) {
        try {
            if (Build.VERSION.SDK_INT < 23) return "";
            String value=context.getSharedPreferences("crm_auth",Context.MODE_PRIVATE).getString("license","");
            if (value.length()>1024) return "";
            String[] parts=value.split("\\."); if(parts.length!=2) return "";
            byte[] iv=Base64.decode(parts[0],Base64.NO_WRAP); if(iv.length!=12) return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(false),new GCMParameterSpec(128,iv));
            return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
        } catch (Exception failure) { return ""; }
    }
}
