package com.easyvictory.mods;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;

/**
 * Small vector-style icons drawn with Canvas paths, so they scale on every density and
 * work on API 19 (VectorDrawable needs API 21). All glyphs are authored in a 100x100 box.
 */
final class EvGlyph extends Drawable {

    static final int SHIELD = 0;
    static final int PLANE = 1;
    static final int BROOM = 2;
    static final int SLIDERS = 3;
    static final int CLOSE = 4;
    static final int MINUS = 5;

    private final int kind;
    private final int sizePx;
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private int color = 0xFF38BDF8;

    private EvGlyph(int kind, int sizePx) {
        this.kind = kind;
        this.sizePx = Math.max(1, sizePx);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        applyColor();
    }

    static EvGlyph create(Context ctx, int kind, int sizeDp) {
        float density = ctx.getResources().getDisplayMetrics().density;
        return new EvGlyph(kind, Math.round(sizeDp * density));
    }

    /** Maps an icon name used by EvIcons ("glyph_broom") to a glyph kind, or -1 if unknown. */
    static int kindForName(String name) {
        if ("glyph_shield".equals(name)) return SHIELD;
        if ("glyph_plane".equals(name)) return PLANE;
        if ("glyph_broom".equals(name)) return BROOM;
        if ("glyph_sliders".equals(name)) return SLIDERS;
        if ("glyph_close".equals(name)) return CLOSE;
        if ("glyph_minus".equals(name)) return MINUS;
        return -1;
    }

    private void applyColor() {
        stroke.setColor(color);
        fill.setColor(color);
    }

    @Override
    public void draw(Canvas canvas) {
        android.graphics.Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        int save = canvas.save();
        canvas.translate(b.left, b.top);
        canvas.scale(b.width() / 100f, b.height() / 100f);
        switch (kind) {
            case SHIELD: drawShield(canvas); break;
            case PLANE: drawPlane(canvas); break;
            case BROOM: drawBroom(canvas); break;
            case SLIDERS: drawSliders(canvas); break;
            case CLOSE: drawClose(canvas); break;
            case MINUS: drawMinus(canvas); break;
            default: break;
        }
        canvas.restoreToCount(save);
    }

    private void drawShield(Canvas c) {
        stroke.setStrokeWidth(6f);
        path.reset();
        path.moveTo(50f, 6f);
        path.lineTo(88f, 20f);
        path.lineTo(88f, 48f);
        path.cubicTo(88f, 72f, 70f, 88f, 50f, 95f);
        path.cubicTo(30f, 88f, 12f, 72f, 12f, 48f);
        path.lineTo(12f, 20f);
        path.close();
        c.drawPath(path, stroke);
        // Crown
        path.reset();
        path.moveTo(30f, 64f);
        path.lineTo(28f, 40f);
        path.lineTo(40f, 52f);
        path.lineTo(50f, 34f);
        path.lineTo(60f, 52f);
        path.lineTo(72f, 40f);
        path.lineTo(70f, 64f);
        path.close();
        c.drawPath(path, fill);
    }

    private void drawPlane(Canvas c) {
        path.reset();
        path.moveTo(94f, 10f);
        path.lineTo(10f, 44f);
        path.lineTo(34f, 54f);
        path.lineTo(42f, 82f);
        path.lineTo(56f, 64f);
        path.lineTo(76f, 80f);
        path.close();
        c.drawPath(path, fill);
    }

    private void drawBroom(Canvas c) {
        stroke.setStrokeWidth(7f);
        c.drawLine(82f, 10f, 54f, 46f, stroke);
        path.reset();
        path.moveTo(48f, 40f);
        path.lineTo(68f, 58f);
        path.lineTo(50f, 88f);
        path.lineTo(12f, 92f);
        path.lineTo(24f, 60f);
        path.close();
        stroke.setStrokeWidth(6f);
        c.drawPath(path, stroke);
        stroke.setStrokeWidth(5f);
        c.drawLine(34f, 62f, 42f, 82f, stroke);
        c.drawLine(46f, 60f, 52f, 78f, stroke);
    }

    private void drawSliders(Canvas c) {
        stroke.setStrokeWidth(7f);
        c.drawLine(10f, 22f, 90f, 22f, stroke);
        c.drawLine(10f, 50f, 90f, 50f, stroke);
        c.drawLine(10f, 78f, 90f, 78f, stroke);
        c.drawCircle(66f, 22f, 10f, fill);
        c.drawCircle(34f, 50f, 10f, fill);
        c.drawCircle(70f, 78f, 10f, fill);
    }

    private void drawClose(Canvas c) {
        stroke.setStrokeWidth(10f);
        c.drawLine(24f, 24f, 76f, 76f, stroke);
        c.drawLine(76f, 24f, 24f, 76f, stroke);
    }

    private void drawMinus(Canvas c) {
        stroke.setStrokeWidth(10f);
        c.drawLine(24f, 50f, 76f, 50f, stroke);
    }

    @Override
    public void setAlpha(int alpha) {
        stroke.setAlpha(alpha);
        fill.setAlpha(alpha);
        invalidateSelf();
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        stroke.setColorFilter(colorFilter);
        fill.setColorFilter(colorFilter);
        invalidateSelf();
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    @Override
    public int getIntrinsicWidth() {
        return sizePx;
    }

    @Override
    public int getIntrinsicHeight() {
        return sizePx;
    }
}
