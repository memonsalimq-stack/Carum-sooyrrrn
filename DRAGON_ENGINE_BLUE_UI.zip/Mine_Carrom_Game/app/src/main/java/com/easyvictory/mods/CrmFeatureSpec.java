package com.easyvictory.mods;

/** The loader consumes the native feature list, not a second set of feature IDs. */
final class CrmFeatureSpec {
    final String type, label;
    final String[] args;
    final int id;
    final boolean global;

    private CrmFeatureSpec(String type, String label, String[] args, int id, boolean global) {
        this.type = type; this.label = label; this.args = args; this.id = id; this.global = global;
    }

    static CrmFeatureSpec parse(String descriptor) {
        if (descriptor == null || descriptor.length() > 4096) throw new IllegalArgumentException("Invalid feature");
        String[] words = descriptor.split("_", -1);
        int index = 0, id = -1;
        boolean global = words.length > 0 && "Global".equals(words[0]);
        if (global || "TabAdd".equals(words[0])) index++;
        if (index < words.length && "True".equals(words[index])) index++;
        if (index < words.length && words[index].matches("-?[0-9]+")) id = Integer.parseInt(words[index++]);
        if (index + 1 >= words.length) throw new IllegalArgumentException("Incomplete feature");
        String type = words[index++], label = words[index++];
        String[] args = java.util.Arrays.copyOfRange(words, index, words.length);
        switch (type) {
            case "SeekBar":
                if (args.length < 2 || Integer.parseInt(args[0]) > Integer.parseInt(args[1]))
                    throw new IllegalArgumentException("Invalid slider range");
                break;
            case "Spinner": case "NativeSpinner": case "ChoiceGrid": case "ColorGrid": case "ButtonLink":
                if (args.length == 0 || args[0].isEmpty()) throw new IllegalArgumentException("Missing control options");
                break;
            case "Tab": case "Toggle": case "Button": case "Status": case "Category": case "RichTextView": break;
            default: throw new IllegalArgumentException("Unknown native control type");
        }
        return new CrmFeatureSpec(type, label, args, id, global);
    }
}
