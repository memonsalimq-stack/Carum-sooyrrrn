package com.easyvictory.mods;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

public abstract class HwMods3 extends TextView {
    public HwMods3(Context context) {
        this(context, null);
    }

    public HwMods3(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public HwMods3(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public abstract void animateText(CharSequence charSequence);

    public abstract void setAnimationListener(HwMods1 animationListener);

    public abstract void setProgress(float f);
}
