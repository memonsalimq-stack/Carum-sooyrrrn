#pragma once
// Created By @GoToHellxD | @HwMods
// Base64: Q3JlYXRlZCBCeSBAR29Ub0hlbGx4RCB8IEBId01vZHM=

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HWM_ABI_VERSION 0x48574D01u

typedef struct CrmPublicConfig {
    uint32_t structSize;
    uint32_t abiVersion;
    int32_t loginEnabled;
    const char* modName;
    const char* modSubtitle;
    const char* modCredit;
    const char* modStatusFree;
    const char* modFreeExpiry;
    const char* panelUrl;
    const char* panelGame;
    const char* panelSalt;
    const char* paramGame;
    const char* paramKey;
    const char* paramSerial;
    const char* extraParams;
    const char* gameLibrary;
} CrmPublicConfig;

typedef struct CrmDrawHost {
    uint32_t structSize;
    double (*getTime)(void);
    int (*isMouseClicked)(int button);
    int (*wantCaptureMouse)(void);
    void (*addLine)(float x1, float y1, float x2, float y2, uint32_t col, float thickness);
    void (*addCircle)(float cx, float cy, float radius, uint32_t col, int segments, float thickness);
    void (*addCircleFilled)(float cx, float cy, float radius, uint32_t col, int segments);
    void (*addRectFilled)(float x1, float y1, float x2, float y2, uint32_t col, float rounding);
    void (*addRect)(float x1, float y1, float x2, float y2, uint32_t col, float rounding, float thickness);
    void (*addText)(float x, float y, uint32_t col, const char* text);
    void (*calcTextSize)(const char* text, float* outW, float* outH);
} CrmDrawHost;

typedef struct CrmCoreCallbacks {
    uint32_t structSize;
    uint32_t initialized;
    void (*startHooks)(void);
    void (*onFrame)(float screenW, float screenH);
    void (*onChange)(int featNum, int value, int booleanVal);
    int (*getFeatureValue)(int featNum);
    void (*getFeatureStatus)(int featNum, char* outBuf, size_t outBufSize);
    int (*isGameLibLoaded)(void);
    int (*isKeyAuthenticated)(void);
    void (*setFreeMode)(int freeMode);
    int (*prepareAuth)(const char* licenseKey, const char* deviceId, const char* gameVersion,
                       int isRenewal, char* outWireBuf, size_t outWireCap,
                       char* outErrBuf, size_t outErrCap, uint64_t* outAttemptToken);
    int (*finishAuth)(uint64_t attemptToken, const char* responseBytes, size_t responseLen,
                      int isRenewal, char* outErrBuf, size_t outErrCap);
    void (*cancelAuth)(uint64_t attemptToken);
    void (*getInfo)(char* outExpiry, size_t expiryCap,
                    char* outStatus, size_t statusCap,
                    char* outCredit, size_t creditCap,
                    char* outModName, size_t nameCap);
} CrmCoreCallbacks;

#if defined(__GNUC__)
#define HWM_PUBLIC __attribute__((visibility("default")))
#else
#define HWM_PUBLIC
#endif

HWM_PUBLIC int hwm_bootstrap(const CrmPublicConfig* cfg, const CrmDrawHost* host, CrmCoreCallbacks* outCallbacks);

#ifdef __cplusplus
}
#endif
